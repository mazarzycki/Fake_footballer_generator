# __init__.py

# Import the modules or subpackages you want to make accessible from the package level
from .data import ENG, ITA, SPA, GER, position
from .generator import FootballerGenerator